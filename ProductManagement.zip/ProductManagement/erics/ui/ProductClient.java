package com.eric.ui;

import java.util.Scanner;
import java.util.Set;

import com.erics.model.Product;
import com.ericsB.service.ProductService;
import com.ericsB.service.IProductService;

public class ProductClient {

    public static void main(String[] args) {
        int prodId = 0;
        String prodName = null;
        Double prodPrice = 0.00;
        String prodCategory = null;
        IProdService service = new ProdService();
        System.out.println("*********Product Management Application**********");
        while (true) {
            System.out.println("1.Add Product");
            System.out.println("2.Update Product");
            System.out.println("3.Delete Product");
            System.out.println("4.Get Product By Id");
            System.out.println("5.Get All Products");
            System.out.println("6.Get All Products By Category");
            System.out.println("7.Get All Products Between Prices");
            System.out.println("8.Get Products By ProductName");

            Scanner scan = new Scanner(System.in);
            int option = scan.nextInt();

            switch (option) {
                case 1:
                    System.out.println("Enter Info To Add Product");
                    System.out.println("Enter Product Id ");
                    prodId = scan.nextInt();
                    System.out.println("Enter Product Name ");
                    prodName = scan.next();
                    System.out.println("Enter Product Price ");
                    prodPrice = scan.nextDouble();
                    System.out.println("Enter Product Category ");
                    prodCategory = scan.next();
                    Prod pro = new Product( prodId,  prodName,  prodPrice,  prodCategory);
                    System.out.println(service.addProduct(pro));
                    break;
                case 2:
                    System.out.println("Enter Info To Update Product");
                    System.out.println("Enter Product Exsisting Id ");
                    prodId = scan.nextInt();
                    System.out.println("Enter Product Name ");
                    prodName = scan.next();
                    System.out.println("Enter Product Price ");
                    prodPrice = scan.nextDouble();
                    System.out.println("Enter Product Category ");
                    prodCategory = scan.next();
                    Product pro1 = new Product(prodId,  prodName,  prodPrice,  prodCategory);
                    System.out.println(service.updateProduct(pro1));
                    break;

                case 3:
                    System.out.println("Enter Product Exsisting Id ");
                    prodId = scan.nextInt();
                    System.out.println(service.deleteProduct(prodId));
                    break;

                case 4:
                    System.out.println("Enter Product Exsisting Id ");
                    prodId = scan.nextInt();
                    System.out.println(service.getProductById(prodId));
                    break;

                case 5:
                    System.out.println("All Product Info:");
                    Set<Product> products = service.getAllProducts();
                    products.stream().forEach(System.out::println);
                    break;
                case 6:
                    System.out.println("All Product Info By Category:");
                    System.out.println("Enter Product Category ");
                    productCategory = scan.next();
                    Set<Product> products0 = service.getAllProductsByCategory(productCategory);
                    products0.stream().forEach(System.out::println);
                    break;

                case 7:
                    System.out.println("All Products Info Inbetween Prices:");
                    System.out.println("Enter Product IntialPrice ");
                    productPrice = scan.nextDouble();
                    System.out.println("Enter Product FinalPrice ");
                    Double productPrice1 = scan.nextDouble();
                    Set<Product> products1 = service.getAllProductInBetweenPrices(productPrice,productPrice1);
                    products1.stream().forEach(System.out::println);
                    break;

                case 8:
                    System.out.println("All Product Info By Name:");
                    System.out.println("Enter Product Name ");
                    prodName = scan.next();
                    Set<Product> products2 = service.getAllProductsByProductName(productName);
                    products2.stream().forEach(System.out::println);
                    break;

                default:
                    System.out.println("Thank You !!!!");
                    System.exit(0);
                    break;
            }
        }
    }

}
